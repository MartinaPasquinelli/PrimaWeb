DELETE 
FROM Prenotazioni
WHERE PrenotazioneId=7;

SELECT*
FROM Prenotazioni;